var express = require('express');
var router = express.Router();
var mysql = require('../public/javascripts/mysql');
var multer = require('multer');
var glob = require('glob');
var fs = require('fs');
var session = require('client-sessions');
var mongo = require('./mongo.js');
var mongoURL = "mongodb://13.56.77.131:27017/Orders";
var bcrypt = require("bcryptjs");
var rn = require('random-number');
var fse = require('fs-extra');


/* GET users listing. */
router.get('/', function (req, res, next) {
    res.send('respond with a resource');
});

var rn = require('random-number');
var options = {
  min:  0,
  max:  10000,
  integer: true
}

router.post('/doLogin', function (req, res, next) {
    // Just checking if the username is in Database table
    console.log("Inside Do Login");

mongo.connect(mongoURL, function(){
    console.log('Connected to mongo at: ' + mongoURL);
    var coll = mongo.collection('users');

    coll.findOne({"email": req.body.username}, function(err, user){
        if (bcrypt.compareSync(req.body.password, user.password)) {
            console.log("Data found in database:",user)
            session.username = req.body.username;
            console.log("Session initialized=> session username: ", session.username);
            res.send({username: session.username,status: 201 });
        } else {
          console.log("User Data not found in the database.")
            res.send({message: "Login failed",status: 401});
        }
    });
});

});

router.post('/doAdminLogin', function (req, res, next) {


    // Just checking if the username is in Database table
    console.log("Inside Do Admin Login");

    mongo.connect(mongoURL, function(){
        console.log('Connected to mongo at: ' + mongoURL);
        var coll = mongo.collection('users');


        coll.findOne({"email": req.body.username}, function(err, user){
            if (bcrypt.compareSync(req.body.password, user.password)) {
                console.log("Data found in database:",user)
                session.username = req.body.username;
                console.log("Session initialized=> session username: ", session.username);
                res.send({username: session.username,status: 201 });
            } else {
                console.log("User Data not found in the database.")
                res.send({message: "Login failed",status: 401});
            }
        });
    });

});
router.post('/doSignUp', function (req, res, next) {
console.log('Inside signup');
// Inserting data into mongoDb and creating folder for user.
mongo.connect(mongoURL, function(){
      console.log('Connected to mongo at: ' + mongoURL);
      var coll = mongo.collection('users');
      // generating salt.
      var salt = bcrypt.genSaltSync(10);
      var hash = bcrypt.hashSync(req.body.password, salt);

      coll.insert({ firstname: req.body.firstname, lastname: req.body.lastname, email: req.body.email, password: hash}, function(err, users){
          if (users) {
            console.log("Data inserted into the users collection under dropbox database");
            var folder = "./public/uploads/Userfiles/" + req.body.email;

            fs.mkdir(folder, function (err) {

                if (!err) {
                    console.log('Directory created');
                    res.status(201).send({message: "Sign Up Successful, Now Login"});
                }
                else {
                    res.status(401).json({message: "SignUp failed"});
                }
            })

          } else {
            console.log("data insertion error while registering..");
            res.status(401).json({message: "SignUp Failed.."});
          }
      });
  });



});


router.get('/doLogout', function (req, res, next) {
    req.session.destroy();
    console.log('Session destroyed');
    res.status(200).json({message:'Logout Successful'});
});

router.post('/createFolder', function (req, res, next) {
    var userPath = session.username;
    console.log('inside crate folder: ', userPath);
    console.log('inside create foldername HAI=>', req.body);

    var newFolder = './public/uploads/Userfiles/' + userPath + '/'+req.body.folderName;

    fs.mkdir(newFolder, function (err) {

        if (!err) {
            console.log('Directory created');
            res.status(201).end();
        }
        else {
            res.status(401).end();

        }
    });
});


var usrs = [];

    router.post('/createSharedFolder', function (req, res, next) {
    var userPath = session.username;
    console.log('inside createSharedfolder: ', userPath);
    console.log('inside createSharedfolder HAI=>', req.body.userlist);

    var newSharedFolder = './public/uploads/Userfiles/' + userPath + '/'+req.body.sharedFolderName;

    console.log("newFolder Path :", newSharedFolder);

    console.log("Userlists to share the folder with: ", req.body.userlist);

    fs.mkdir(newSharedFolder, function (err) {
        if (!err) {
            console.log('Directory created');
        }
        else {
            res.status(401).end();
        }
    });

  var rand = rn(options);
  console.log(rand);
    // insert data about group into the collection(groups).
    mongo.connect(mongoURL, function(){
          console.log('Connected to mongo at: ' + mongoURL);
          var coll = mongo.collection('groups');

          coll.insert({ GID: rand, admin: session.username}, function(err, users){
              if (users) {
                console.log("Data inserted into the groups collection for group description.");

              } else {
                console.log("data insertion error in groups collection.");
              }
          });
      });

      // logic to insert data into groups collection ends here.

// inserting data into groupDetails about admin starts here.
// inserting details about group and its members in groupDetails collection.
mongo.connect(mongoURL, function(){
      console.log('Connected to mongo at: ' + mongoURL);
      var coll = mongo.collection('groupDetails');

      coll.insert({ GID: rand, admin: session.username, username: session.username}, function(err, users){
          if (users) {
            console.log("Data inserted into the groups collection for group description.");

          } else {
            console.log("data insertion error in groups collection.");
          }
      });
  });

// logic to insert data into the groupDetails about admin ends here.
    console.log("userlists in which we have to create the shared folder are: ", req.body.userlist);
    var userlists = req.body.userlist;
    userlists = userlists.split(',');

    for(var i=0;i<userlists.length;i++) {

      var newSharedFolder = './public/uploads/Userfiles/' + userlists[i] + '/'+req.body.sharedFolderName;
      fs.mkdir(newSharedFolder, function (err) {

          if (!err) {
              console.log('Directory created');
            //  res.status(201).end();
          }
          else {
              res.status(401).end();
          }
      });
    }
    // inserting details about group and its members in groupDetails collection.
    console.log("length of userlist array :  ", userlists.length);
    console.log("contents of userlists array:   ", userlists);


  for(var j=0;j<userlists.length;j++) {
    mongo.connect(mongoURL, function(){
          console.log('Connected to mongo at: ' + mongoURL);
          var coll = mongo.collection('groupDetails');

          console.log("user deails:--------- ",userlists[j]);

          coll.insert({ GID: rand, admin: session.username, username: JSON.stringify(userlists[j])}, function(err, users){
              if (users) {
                console.log("Data inserted into the groups collection for group description.");
              } else {
                console.log("data insertion error in groups collection.");
              }
          });
      });
    }
// logic to insert data into groupDetails ends here.
    res.status(201).end();

});

/*router.post('/handleCheckout',function(req,res){
    console.log('Inside cart handler:');

    mongo.connect(mongoURL, function(){
        console.log('Connected to mongo at: ' + mongoURL);
        var coll = mongo.collection('cart');
        console.log(req.body);
        coll.insertOne(req.body,function(err, user){
            if (user) {
                res.status(201).json(user);
            } else {

                res.status(401).json({wrong:1});
            }
        });
    });

});*/

router.post('/handleCheckout1', function(req, res) {
    console.log("XXXXXXXXXXXXXXXXX");
    console.log(req.body);
    mongo.connect(mongoURL, function(){
        console.log('Connected to mongo at: ' + mongoURL);
        var coll = mongo.collection('cart');
        console.log(req.body);
        coll.save(req.body,function(err, user){
            if (user) {
                console.log("User Details : ", user.id);
                res.status(201).json({status:201,user:user});
            } else {

                res.status(401).json({status:401,wrong:1});
            }
        });
    });
});

router.post('/getMenu', function(req, res) {
    console.log("");
    console.log(req.body);

    mongo.connect(mongoURL, function(){
        console.log('Connected to mongo at: ' + mongoURL);
        var coll = mongo.collection('cart');
        console.log(req.body);
        console.log("a");
        coll.find({}).toArray(function(err, user){
            if (user) {
                console.log(user);
                res.status(201).json(user);
            } else {

                res.status(201).json({wrong:1});
            }
        });
    });

});




module.exports = router;
