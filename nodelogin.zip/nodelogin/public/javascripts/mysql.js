var mysql = require('mysql');


//Put your mysql configuration settings - user, password, database and port
function getConnection(){
    var connection = mysql.createConnection({
        host     : 'localhost',
        user     : 'root',
        password : 'password',
        database : 'lab1',
        port	 : 3306
    });
    console.log('=>inside getConnection=>connection:blah blah');
    return connection;
}


function fetchData(callback,sqlQuery){

    console.log("\nInside mysql.js=>fetchData=>SQL Query::",sqlQuery);

    var connection = getConnection();

    connection.query(sqlQuery, function(err, rows, fields) {
        if(err){
            console.log("ERROR: " + err.message);
        }
        else
        {	// return err or result
            console.log("DB Results:"+rows);
            callback(err, rows);
        }
    });
    console.log("\nConnection closed..");
    connection.end();
}

function insertData(callback,sqlQuery) {
    console.log("\nInside mysql.js=>insertData=>SQL Query::",sqlQuery);

    var connection = getConnection();

    connection.query(sqlQuery, function(err, rows, fields) {
        if(err){
            console.log("ERROR IN INSERT: " + err.message);
        }
        else
        {	// return err or result
            console.log("DB Results:"+rows);
            callback(err, rows);
        }
    });
    console.log("\nConnection closed..");
    connection.end();

}

exports.fetchData=fetchData;
exports.insertData=insertData;
